<?php

namespace App\Models\Enums;

use App\Foundation\Models\Enums\Enum;

class SpecialArticle extends Enum
{
    const HOME = 'home';
}
