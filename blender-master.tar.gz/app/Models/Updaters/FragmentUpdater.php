<?php

namespace App\Models\Updaters;

use App\Foundation\Models\Updaters\TranslatableUpdater;

class FragmentUpdater extends TranslatableUpdater
{
}
