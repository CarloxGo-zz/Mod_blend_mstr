<?php

namespace App\Foundation\Models\Translations;

use Illuminate\Database\Eloquent\Model;

class Translation extends Model
{
    public $timestamps = false;
    protected $guarded = ['id'];
}
