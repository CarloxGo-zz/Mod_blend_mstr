<?php

namespace App\Foundation\Models\Enums;

use Exception;

class EnumTypesDontMatch extends Exception
{
}
