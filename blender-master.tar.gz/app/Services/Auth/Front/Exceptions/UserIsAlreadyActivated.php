<?php

namespace App\Services\Auth\Front\Exceptions;

use Exception;

class UserIsAlreadyActivated extends Exception
{
}
