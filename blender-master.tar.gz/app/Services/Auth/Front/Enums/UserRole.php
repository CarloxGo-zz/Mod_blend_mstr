<?php

namespace App\Services\Auth\Front\Enums;

use App\Foundation\Models\Enums\Enum;

/**
 * @method static MEMBER()
 */
class UserRole extends Enum
{
    const MEMBER = 'member';
}
