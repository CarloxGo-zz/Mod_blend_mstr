<?php

namespace App\Services\Auth\Back\Exceptions;

use Exception;

class UserIsAlreadyActivated extends Exception
{
}
