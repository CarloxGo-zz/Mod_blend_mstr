<?php

namespace App\Http\Controllers\Back;

use App\Http\Controllers\Controller;
use Analytics;
use Spatie\Analytics\Period;

class StatisticsController extends Controller
{
    public function index()
    {
        if (empty(config('laravel-analytics.view_id'))) {
            return view('back.statistics.notconfigured');
        }

        $visitors = Analytics::fetchVisitorsAndPageViews(Period::days(365))
            ->groupBy(function (array $visitorStatistics) {
                return $visitorStatistics['date']->format('Y-m');
            })
            ->map(function ($visitorStatistics, $yearMonth) {
                list($year, $month) = explode('-', $yearMonth);

                return [
                    'date' => "{$month}-{$year}",
                    'visitors' => $visitorStatistics->sum('visitors'),
                    'pageViews' => $visitorStatistics->sum('pageViews')
                ];
            })
            ->values();

        $pages = Analytics::fetchMostVisitedPages(Period::days(365));
        $referrers = Analytics::fetchTopReferrers(Period::days(365));
        $browsers = Analytics::fetchTopBrowsers(Period::days(365));

        return view('back.statistics.index') ->with(compact('visitors', 'pages', 'referrers', 'browsers'));
    }
}
