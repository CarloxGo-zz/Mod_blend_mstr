<?php

namespace App\Http\Routes;

use MyCLabs\Enum\Enum;

class Route extends Enum
{
    const HOME = 'home';
    const CONTACT = 'contact';
}
