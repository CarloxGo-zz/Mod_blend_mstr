<?php

namespace App\Test\Integration;

class Exception extends \Exception
{
}
