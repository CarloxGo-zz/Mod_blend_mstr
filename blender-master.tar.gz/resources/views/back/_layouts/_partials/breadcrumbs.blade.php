<nav class="breadcrumbs">
    @yield('breadcrumbs')
</nav>
