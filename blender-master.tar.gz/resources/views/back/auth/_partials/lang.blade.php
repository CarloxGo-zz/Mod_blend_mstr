<nav class="+auth_lang">
    {!! Navigation::getBackLanguageMenu() !!}
</nav>
