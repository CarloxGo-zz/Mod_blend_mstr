<?php

return [

    /*
     * The default serializer to be used when performing a transformation.
     * Leave empty to use the Fractal's default.
     */
    'default_serializer' => Spatie\Fractal\ArraySerializer::class,
];
