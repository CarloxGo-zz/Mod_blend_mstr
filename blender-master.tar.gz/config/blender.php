<?php

return [
    'version' => '5.4.4',
    'installDate' => '06/2016',
];
