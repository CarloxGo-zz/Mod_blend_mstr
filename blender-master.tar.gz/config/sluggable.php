<?php

return [
    'save_to'         => 'url',
    'separator'       => '-',
    'on_update'       => true,
];
