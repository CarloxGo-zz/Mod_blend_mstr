<?php
return [
    'alsoLogInDefaultLog' => true,
    'deleteRecordsOlderThanMonths' => 2,
    'userModel' => App\Services\Auth\Back\User::class,
];
