<?php

return [
    /*
     * The path to redirect for login.
     * Gets overwritten in the ConfigServiceProvider.
     */
    'login_url' => 'login',
];
